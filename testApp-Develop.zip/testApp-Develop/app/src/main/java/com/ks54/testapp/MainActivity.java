package com.ks54.testapp;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.NetworkError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    JSONObject myUser = null;
    JSONObject myUsers = null;

    int card_back_activity;
    int getstate = 0;

    String db_address;
    //String db_port;
    SharedPreferences sPref;

    final String DB_ADDRESS = "db_address";
    final String DB_PORT = "db_port";
    final int LEVELGRADEONE = 2;
    final int LEVELGRADETWO = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkDBaddress();
    }

    public void checkDBaddress(){
        db_address = loadPref(DB_ADDRESS);
        TextView mytxt = findViewById(R.id.textView5);
        Button login_button = findViewById(R.id.login_button);
        if(db_address.equals("")){
            //mytxt.setVisibility(View.VISIBLE);
            login_button.setClickable(false);
            mytxt.setText(R.string.db_address_fail);
        }
        else{
            //mytxt.setVisibility(View.VISIBLE);
            login_button.setClickable(true);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.tab_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if (item.getItemId() == R.id.menu_pref) {
            setContentView(R.layout.preff_screen);
            EditText login_field = findViewById(R.id.preff_ip_entry);
            EditText port_field = findViewById(R.id.preff_port_entry);
            login_field.setText(loadPref(DB_ADDRESS));
            port_field.setText(loadPref(DB_PORT)); //DO check EMPTY STRING
        }
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    public void buttonHandler(View v) throws JSONException {
        switch(v.getId()){
            case R.id.login_button:
                String urlLogin = "none";
                String urlPwd = "none";
                EditText logField = findViewById(R.id.LoginEntry);
                EditText pwdField = findViewById(R.id.PwdEntry);
                String curLogin = logField.getText().toString();
                String curPwd = pwdField.getText().toString();

                if (!curLogin.equals("")){
                    urlLogin = curLogin;
                }
                if (!curPwd.equals("")){
                    urlPwd = curPwd;
                }

                //String url = "http://192.168.1.137/phpQuery3.php?login=" + urlLogin + "&pwd=" + urlPwd;
                String url = String.format("http://%s/%s?login=%s&pwd=%s", loadPref(DB_ADDRESS), getString(R.string.php_login), urlLogin, urlPwd);
                //System.out.println(url);
                Button login_button = findViewById(R.id.login_button);
                login_button.setClickable(false);
                this.loginHTTPGet(url);
                break;

            case R.id.cardBackButton:
                switch(card_back_activity){
                    case R.layout.user_list:
                        String url2 = String.format("http://%s/%s?idreg=all", loadPref(DB_ADDRESS), getString(R.string.php_getusers));
                        Button button = findViewById(R.id.cardBackButton);
                        button.setClickable(false);
                        getstate = 1;
                        this.runHTTPGet(url2, button);
                        break;

                    case R.layout.menu_tab:
                        formMenu();
                        break;

                    default:
                        setContentView(card_back_activity);
                        break;
                }

                break;

            case R.id.preff_apply:
                EditText db_address = findViewById(R.id.preff_ip_entry);
                savePref(DB_ADDRESS, db_address.getText().toString());
                EditText db_port = findViewById(R.id.preff_port_entry);
                savePref(DB_PORT, db_port.getText().toString());
                setContentView(R.layout.activity_main);
                checkDBaddress();
                break;

            case R.id.preff_cancel:
                setContentView(R.layout.activity_main);
                checkDBaddress();
                break;

            case R.id.menu_button_user_card:
                card_back_activity = R.layout.menu_tab;
                CardUser.user = myUser.getJSONObject("0");
                formUserCard(CardUser.user);
                break;

            case R.id.cardChangeButton:
                setContentView(R.layout.changeuserdata);
                formChangeScreen(CardUser.user);
                break;

            case R.id.cardDeleteButton:
                doDelete();
                break;

            case R.id.changeApplyButton:
                doChange();
                break;

            case R.id.changeCancelButton:
                formUserCard(CardUser.user);
                break;

            case R.id.menu_button_user_list:
                String url2 = String.format("http://%s/%s?idreg=all", loadPref(DB_ADDRESS), getString(R.string.php_getusers));
                Button list_button = findViewById(R.id.menu_button_user_list);
                list_button.setClickable(false);
                getstate = 1;
                this.runHTTPGet(url2, list_button);
                break;

            case R.id.menu_button_add_card:
                //setContentView(R.layout.activity_main);
                //checkDBaddress();
                break;

            case R.id.menu_button_back:
                setContentView(R.layout.activity_main);
                break;

            case R.id.user_list_back_button:
                formMenu();
                break;

        }
    }

    public void loginHTTPGet(String url){
        RequestQueue queue = Volley.newRequestQueue(this);

        @SuppressLint("DefaultLocale") StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        myUser = new JSONObject(response);
                        Button login_button = findViewById(R.id.login_button);
                        login_button.setClickable(true);
                        login_confirmation();
                    } catch (JSONException e) {
                        Button login_button = findViewById(R.id.login_button);
                        login_button.setClickable(true);
                        System.out.println(response);
                        e.printStackTrace();
                    }
                },
                error -> {
                    TextView mytxt = findViewById(R.id.textView5);
                    if(error instanceof TimeoutError){
                        mytxt.setText(String.format("%s: %s", getString(R.string.connect_fail), "TimeoutError"));
                    }
                    else if(error instanceof ServerError){
                        mytxt.setText(String.format("%s: %s", getString(R.string.connect_fail), "ServerError"));
                    }
                    else if(error instanceof NetworkError){
                        mytxt.setText(String.format("%s: %s", getString(R.string.connect_fail), "NetworkError"));
                    }
                    else if(error instanceof ParseError){
                        mytxt.setText(String.format("%s: %s", getString(R.string.connect_fail), "ParseError"));
                    }
                    else{
                        mytxt.setText(String.format("%s: %s", getString(R.string.connect_fail), "Unknown error"));
                    }

                    Button login_button = findViewById(R.id.login_button);
                    login_button.setClickable(true);
                });
        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

    public void runHTTPGet(String url) { // overridden method
        runHTTPGet(url, null);
    }
    public void runHTTPGet(String url, Button button){
        RequestQueue queue = Volley.newRequestQueue(this);

        @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        switch (getstate) {
                            case 1:
                                if(button!=null) {
                                    button.setClickable(true);
                                }
                                myUsers = new JSONObject(response);
                                user_list_form();
                                break;

                            case 2:
                                Button applybutton = findViewById(R.id.changeApplyButton);
                                Button cancelbutton = findViewById(R.id.changeCancelButton);
                                applybutton.setClickable(true);
                                cancelbutton.setClickable(true);
                                myUsers = new JSONObject(response);
                                CardUser.user = myUsers.getJSONObject("0");
                                formUserCard(CardUser.user);
                                break;

                            case 3:
                                Button buttonChange = findViewById(R.id.cardBackButton);
                                Button buttonDelete = findViewById(R.id.cardChangeButton);
                                Button buttonBack = findViewById(R.id.cardDeleteButton);
                                buttonChange.setClickable(true);
                                buttonDelete.setClickable(true);
                                buttonBack.setClickable(true);
                                getstate = 1;
                                String url2 = String.format("http://%s/%s?idreg=all", loadPref(DB_ADDRESS), getString(R.string.php_getusers));
                                this.runHTTPGet(url2);
                                break;
                        }
                    } catch (JSONException e) {
                        TextView errorText = findViewById(R.id.menu_Error_text);
                        errorText.setText("Data was corrupted");
                        //e.printStackTrace();
                    }
                },
                error -> {
                    //System.out.println(error);
                    final TextView errorText;
                    switch(getstate){
                        case 1:
                            Button list_button = findViewById(R.id.menu_button_user_list);
                            list_button.setClickable(true);
                            errorText = findViewById(R.id.menu_Error_text);
                            errorText.setText(error.getMessage());
                            break;

                        case 2:
                            Button applybutton = findViewById(R.id.changeApplyButton);
                            Button cancelbutton = findViewById(R.id.changeCancelButton);
                            applybutton.setClickable(true);
                            cancelbutton.setClickable(true);
                            errorText = findViewById(R.id.change_Error_text);
                            errorText.setText(R.string.change_fail);
                            break;

                        case 3:
                            Button buttonChange = findViewById(R.id.cardBackButton);
                            Button buttonDelete = findViewById(R.id.cardChangeButton);
                            Button buttonBack = findViewById(R.id.cardDeleteButton);
                            buttonChange.setClickable(true);
                            buttonDelete.setClickable(true);
                            buttonBack.setClickable(true);
                            errorText = findViewById(R.id.change_Error_text);
                            errorText.setText(R.string.delete_fail);
                            break;
                    }
                });
        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

    public void runHTTPSet(String url, String id){
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    String url1 = String.format("http://%s/%s?idreg=%s", loadPref(DB_ADDRESS), getString(R.string.php_getusers), id);
                    getstate = 2;
                    runHTTPGet(url1);
                },
                error -> {
                    Button applybutton = findViewById(R.id.changeApplyButton);
                    Button cancelbutton = findViewById(R.id.changeCancelButton);
                    applybutton.setClickable(true);
                    cancelbutton.setClickable(true);
                    TextView errorText = findViewById(R.id.change_Error_text);
                    errorText.setText(error.getMessage());
                });

        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

    public void login_confirmation() throws JSONException {
        EditText logField = findViewById(R.id.LoginEntry);
        EditText pwdField = findViewById(R.id.PwdEntry);

        TextView mytxt = findViewById(R.id.textView5);

        if (myUser.getString("access").equals("granted")){
            logField.setText("");
            pwdField.setText("");

            formMenu();
        }
        else{
            // execute Login ERROR MESSAGE
            //mytxt.setText(R.string.login_fail + myUser.getString("access"));
            mytxt.setText(String.format("%s %s", getString(R.string.login_fail), myUser.getString("access")));
            pwdField.setText("");
        }
    }

    public void user_list_form() throws JSONException {
        setContentView(R.layout.user_list);
        ListView listView = findViewById(R.id.user_list_list);

        ArrayList<UserListData> userslist = new ArrayList<>();

        int currentUserLevel = Integer.parseInt(myUser.getJSONObject("0").getString("LEVEL"));
        for(int i = 0; i < myUsers.length()-1; i++){
            int listUsrLevel = Integer.parseInt(myUsers.getJSONObject(String.valueOf(i)).getString("LEVEL"));
            if(currentUserLevel >= listUsrLevel) {
                UserListData listUser = new UserListData(myUsers.getJSONObject(String.valueOf(i)).getString("Id_Reg"),
                        myUsers.getJSONObject(String.valueOf(i)).getString("UserName"),
                        myUsers.getJSONObject(String.valueOf(i)).getString("UserSurName"),
                        Integer.parseInt(myUsers.getJSONObject(String.valueOf(i)).getString("LEVEL")));
                userslist.add(listUser);
            }
        }
        userslist.sort((a, b) -> -Integer.compare(a.getUserLevel(), b.getUserLevel()));

        CustomListViewAdapter adapter = new CustomListViewAdapter(this, userslist);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            card_back_activity = R.layout.user_list;
            setContentView(R.layout.user_card);
            for(int i = 0; i < myUsers.length()-1; i++){
                try {
                    if(myUsers.getJSONObject(Integer.toString(i)).getString("Id_Reg")
                            .equals(userslist.get(position).getUserRegId())){
                        CardUser.user = myUsers.getJSONObject(Integer.toString(i));
                        formUserCard(CardUser.user);
                        break;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void formMenu() throws JSONException {
        setContentView(R.layout.menu_tab);
        Button cardButton = findViewById(R.id.menu_button_user_card);
        Button listButton = findViewById(R.id.menu_button_user_list);
        Button addButton = findViewById(R.id.menu_button_add_card);

        addButton.setVisibility(View.INVISIBLE);
        if(Integer.parseInt(myUser.getJSONObject("0").getString("LEVEL")) > LEVELGRADEONE){
            cardButton.setVisibility(View.VISIBLE);
            listButton.setVisibility(View.VISIBLE);
        }
        else{
            cardButton.setVisibility(View.VISIBLE);
            listButton.setVisibility(View.INVISIBLE);
        }
    }

    public void formUserCard(JSONObject obj) throws JSONException {
        setContentView(R.layout.user_card);
        TextView nameTxt = findViewById(R.id.cardNameText);
        TextView surnameTxt = findViewById(R.id.cardSurnameText);
        TextView loginTxt = findViewById(R.id.cardLoginText);
        TextView levelTxt = findViewById(R.id.cardLevelText);
        TextView idCardTxt = findViewById(R.id.cardCardIdtext);
        TextView idRegtxt = findViewById(R.id.cardRedIdText);
        TextView lastTimeTxt = findViewById(R.id.cardTimeText);

        Button changeButton = findViewById(R.id.cardChangeButton);
        Button deleteButton = findViewById(R.id.cardDeleteButton);
        TextView idCardLabel = findViewById(R.id.cardCardIdLabel);
        TextView idRegLabel = findViewById(R.id.cardRegIdLabel);

        nameTxt.setText(obj.getString("UserName"));
        surnameTxt.setText(obj.getString("UserSurName"));
        loginTxt.setText(obj.getString("Login"));
        levelTxt.setText(obj.getString("LEVEL"));
        idCardTxt.setText(obj.getString("Id_Card"));
        idRegtxt.setText(obj.getString("Id_Reg"));
        lastTimeTxt.setText(String.format("%s  %s", obj.getString("Last_time"), obj.getString("Last_date")));

        if(Integer.parseInt(myUser.getJSONObject("0").getString("LEVEL")) > LEVELGRADEONE){
            idCardTxt.setVisibility(View.VISIBLE);
            idRegtxt.setVisibility(View.VISIBLE);
            idCardLabel.setVisibility(View.VISIBLE);
            idRegLabel.setVisibility(View.VISIBLE);
            changeButton.setVisibility(View.VISIBLE);
            deleteButton.setVisibility(View.VISIBLE);
        }
        else{
            idCardTxt.setVisibility(View.INVISIBLE);
            idRegtxt.setVisibility(View.INVISIBLE);
            idCardLabel.setVisibility(View.INVISIBLE);
            idRegLabel.setVisibility(View.INVISIBLE);
            changeButton.setVisibility(View.INVISIBLE);
            deleteButton.setVisibility(View.INVISIBLE);
        }

        if(!obj.getString("Id_Reg").equals(myUser.getJSONObject("0").getString("Id_Reg"))) {
            if (obj.getString("LEVEL").equals(myUser.getJSONObject("0").getString("LEVEL"))) {
                changeButton.setEnabled(false);
                changeButton.setFocusable(false);
                deleteButton.setEnabled(false);
                deleteButton.setFocusable(false);
            }
            else {
                if(Integer.parseInt(myUser.getJSONObject("0").getString("LEVEL")) > LEVELGRADETWO){
                    deleteButton.setEnabled(true);
                    deleteButton.setFocusable(true);
                }
                else{
                    deleteButton.setEnabled(false);
                    deleteButton.setFocusable(false);
                }
                changeButton.setEnabled(true);
                changeButton.setFocusable(true);
            }
        }
        else{
            deleteButton.setEnabled(false);
            deleteButton.setFocusable(false);
            changeButton.setEnabled(true);
            changeButton.setFocusable(true);
        }
    }

    public void formChangeScreen(JSONObject obj) throws JSONException {
        EditText nameTxt = findViewById(R.id.changeName);
        EditText surnameTxt = findViewById(R.id.changeSurname);
        EditText loginTxt = findViewById(R.id.changeLogin);
        EditText levelTxt = findViewById(R.id.changeLevel);
        EditText pwdTxt = findViewById(R.id.changePwd);
        Button applyButton = findViewById(R.id.changeApplyButton);






        nameTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                setChangeErrorText(nameTxt, findViewById(R.id.change_username_error), applyButton);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        surnameTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                setChangeErrorText(surnameTxt, findViewById(R.id.change_usersurname_error), applyButton);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        loginTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                setChangeErrorText(loginTxt, findViewById(R.id.change_userlogin_error), applyButton);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        levelTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                TextView errorText;
                try {
                    int x = Integer.parseInt(myUser.getJSONObject("0").getString("LEVEL"));
                    int y;
                    errorText = findViewById(R.id.change_level_error);
                    if(levelTxt.getText().toString().equals("")){
                        errorText.setText(R.string.change_empty);
                        applyButton.setEnabled(false);
                        applyButton.setFocusable(false);
                    }
                    else{
                        y = Integer.parseInt(levelTxt.getText().toString());
                        if(!obj.getString("Id_Reg").equals(myUser.getJSONObject("0").getString("Id_Reg"))){
                            if(x <= y){
                                errorText.setText(R.string.change_levelerror);
                                applyButton.setEnabled(false);
                                applyButton.setFocusable(false);
                            }
                            else{
                                errorText.setText("");
                                applyButton.setEnabled(true);
                                applyButton.setFocusable(true);
                            }
                        }
                        else{
                            if(x < y){
                                errorText.setText(R.string.change_levelerror);
                                applyButton.setEnabled(false);
                                applyButton.setFocusable(false);
                            }
                            else{
                                errorText.setText("");
                                applyButton.setEnabled(true);
                                applyButton.setFocusable(true);
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }


        });
        pwdTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                setChangeErrorText(pwdTxt, findViewById(R.id.change_userpassword_error), applyButton);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        nameTxt.setText(obj.getString("UserName"));
        surnameTxt.setText(obj.getString("UserSurName"));
        loginTxt.setText(obj.getString("Login"));
        levelTxt.setText(obj.getString("LEVEL"));
        pwdTxt.setText("");

        if(obj.getString("Id_Reg").equals(myUser.getJSONObject("0").getString("Id_Reg"))){
            levelTxt.setEnabled(false);
            levelTxt.setFocusable(false);
        }
        else{
            levelTxt.setEnabled(true);
            levelTxt.setFocusable(true);
        }
    }

    public void doChange() throws JSONException {
        EditText nameTxt = findViewById(R.id.changeName);
        EditText surnameTxt = findViewById(R.id.changeSurname);
        EditText loginTxt = findViewById(R.id.changeLogin);
        EditText levelTxt = findViewById(R.id.changeLevel);
        EditText pwdTxt = findViewById(R.id.changePwd);

        String url = String.format("http://%s/%s?idreg=%s&username=%s&usersurname=%s&login=%s&level=%s&pwd=%s",
                loadPref(DB_ADDRESS), getString(R.string.php_update), CardUser.user.getString("Id_Reg"), nameTxt.getText(), surnameTxt.getText(),
                loginTxt.getText(), levelTxt.getText(), pwdTxt.getText());

        Button applybutton = findViewById(R.id.changeApplyButton);
        Button cancelbutton = findViewById(R.id.changeCancelButton);
        applybutton.setClickable(false);
        cancelbutton.setClickable(false);
        runHTTPSet(url, CardUser.user.getString("Id_Reg"));
    }

    public void doDelete() throws JSONException {
        String url3 = String.format("http://%s/%s?cardid=%s", loadPref(DB_ADDRESS), getString(R.string.php_delete), CardUser.getIdCard());
        Button buttonChange = findViewById(R.id.cardBackButton);
        Button buttonDelete = findViewById(R.id.cardChangeButton);
        Button buttonBack = findViewById(R.id.cardDeleteButton);
        buttonChange.setClickable(false);
        buttonDelete.setClickable(false);
        buttonBack.setClickable(false);
        getstate = 3;
        this.runHTTPGet(url3);
    }

    void savePref(String pref, String value) {
        sPref = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor ed = sPref.edit();
        ed.putString(pref, value);
        ed.apply();
        Toast.makeText(this, "Preferences saved", Toast.LENGTH_SHORT).show();
    }

    private void setChangeErrorText(EditText edTxt, TextView txtView, Button btn){
        if(edTxt.getText().toString().equals("")){
            txtView.setText(R.string.change_empty);
            btn.setEnabled(false);
            btn.setFocusable(false);
        }else{
            txtView.setText("");
            btn.setEnabled(true);
            btn.setFocusable(true);
        }
    }

    String loadPref(String pref) {
        sPref = getPreferences(MODE_PRIVATE);
        return sPref.getString(pref, "");
    }
}