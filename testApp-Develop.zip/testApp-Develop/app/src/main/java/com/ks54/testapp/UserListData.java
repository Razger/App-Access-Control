package com.ks54.testapp;

public class UserListData {
    String regid;
    String username;
    String usersurname;
    int level;

    public UserListData(String regid, String username, String usersurname, int level) {
        this.regid = regid;
        this.username=username;
        this.usersurname=usersurname;
        this.level=level;
    }

    public String getUserRegId() {
        return regid;
    }

    public int getUserLevel() {
        return level;
    }
}
