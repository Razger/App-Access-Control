package com.ks54.testapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomListViewAdapter extends BaseAdapter {
    Context ctx;
    LayoutInflater lInflater;
    ArrayList<UserListData> objects;

    int[] imagesIdList = {
            R.drawable.level_1,
            R.drawable.level_2,
            R.drawable.level_3,
            R.drawable.level_4,
            R.drawable.level_5,
            R.drawable.level_6,
            R.drawable.level_7,
            R.drawable.level_8,
            R.drawable.level_9,
            R.drawable.level_10
    };

    CustomListViewAdapter(Context context, ArrayList<UserListData> products) {
        ctx = context;
        objects = products;
        lInflater = (LayoutInflater) ctx
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return objects.size();
    }

    @Override
    public Object getItem(int position) {
        return objects.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = lInflater.inflate(R.layout.listitem, parent, false);
        }

        UserListData p = getUser(position);

        // заполняем View в пункте списка данными из пользователей: имя, фамилия и иконка уровня доступа
        ((TextView) view.findViewById(R.id.user_name)).setText(String.format("%s ", p.username));
        ((TextView) view.findViewById(R.id.user_surname)).setText(p.usersurname);
        ((ImageView) view.findViewById(R.id.level_image))
                        .setImageResource(imagesIdList[p.level-1]);

        return view;
    }

    // пользователь по позиции
    UserListData getUser(int position) {
        return ((UserListData) getItem(position));
    }

}