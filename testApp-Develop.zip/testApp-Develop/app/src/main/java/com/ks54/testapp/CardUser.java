package com.ks54.testapp;

import org.json.JSONException;
import org.json.JSONObject;

public class CardUser {
    static public JSONObject user;

    static public String getIdCard() throws JSONException {
        return user.getString("Id_Card");
    }
}
